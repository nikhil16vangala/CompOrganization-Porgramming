/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=18x10 bomb2 bomb2.jpg 
 * Time-stamp: Tuesday 04/06/2021, 17:01:30
 * 
 * Image Information
 * -----------------
 * bomb2.jpg 18@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BOMB2_H
#define BOMB2_H

extern const unsigned short bomb2[180];
#define BOMB2_SIZE 360
#define BOMB2_LENGTH 180
#define BOMB2_WIDTH 18
#define BOMB2_HEIGHT 10

#endif


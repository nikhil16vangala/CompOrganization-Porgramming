/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 gameover1 gameover1.jpg 
 * Time-stamp: Thursday 04/08/2021, 00:26:27
 * 
 * Image Information
 * -----------------
 * gameover1.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMEOVER1_H
#define GAMEOVER1_H

extern const unsigned short gameover1[38400];
#define GAMEOVER1_SIZE 76800
#define GAMEOVER1_LENGTH 38400
#define GAMEOVER1_WIDTH 240
#define GAMEOVER1_HEIGHT 160

#endif


/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 city2 city2.jpg 
 * Time-stamp: Tuesday 04/06/2021, 20:54:38
 * 
 * Image Information
 * -----------------
 * city2.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CITY2_H
#define CITY2_H

extern const unsigned short city2[38400];
#define CITY2_SIZE 76800
#define CITY2_LENGTH 38400
#define CITY2_WIDTH 240
#define CITY2_HEIGHT 160

#endif


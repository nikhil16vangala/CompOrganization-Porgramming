This game is called "Save the City"
The Enter button allows the player to replay the game at anytime during the game.
The Backspace button allows the player to return to the start screen at anytime during the game.
The left and right arrow buttons allows the player to move the shield.
The longer you keep the bomb in the air, the higher your score.
If the bomb drops below the shield and falls on the city, the city explodes and you lose the game.
Get Ready!!!!!
